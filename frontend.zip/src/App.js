import React from "react";
import { BrowserRouter as Router, Route, Routes } from "react-router-dom";
import LoginPage from "./LoginPage";
import MoviesPage from "./MoviesPage";
import ShowPage from "./ShowPage";
import SelectSeatsPage from "./SelectSeatsPage";
import PaymentPage from "./PaymentPage"; // Import the PaymentPage component

function App() {
  return (
    <Router>
      <Routes>
        {/* Route for LoginPage */}
        <Route path="/" element={<LoginPage />} />

        {/* Route for MoviesPage */}
        <Route path="/movies" element={<MoviesPage />} />

        {/* Route for ShowPage */}
        <Route path="/shows" element={<ShowPage />} />

        {/* Route for SelectSeatsPage */}
        <Route path="/select-seats" element={<SelectSeatsPage />} />

        {/* Route for PaymentPage */}
        <Route path="/payment" element={<PaymentPage />} />
      </Routes>
    </Router>
  );
}

export default App;
