import React, { useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { Button, Input, Modal, Typography, Radio, Card, notification } from "antd";

const { Title, Text } = Typography;

function PaymentPage() {
  const { state } = useLocation();
  const { totalPrice } = state || {};
  const navigate = useNavigate();
  const [paymentMethod, setPaymentMethod] = useState("");
  const [showCreditCard, setShowCreditCard] = useState(false);
  const [showUPI, setShowUPI] = useState(false);

  const handlePaymentMethodChange = (e) => {
    const method = e.target.value;
    setPaymentMethod(method);
    if (method === "creditCard") {
      setShowCreditCard(true);
      setShowUPI(false);
    } else if (method === "upi") {
      setShowUPI(true);
      setShowCreditCard(false);
    }
  };

  const handlePaymentSuccess = () => {
    // Display notification
    notification.success({
      message: "Payment Successful",
      description: "Your payment has been processed successfully!",
    });

    // Redirect to the login page after a delay
    setTimeout(() => {
      navigate("/login");
    }, 2000); // Redirect after 2 seconds
  };

  return (
    <Card style={{ maxWidth: "600px", margin: "20px auto", padding: "20px" }}>
      <Title level={2}>Payment Page</Title>
      <div style={{ marginBottom: "20px" }}>
        <Text strong>Total Price:</Text> <Text>₹{totalPrice}</Text>
      </div>

      <div>
        <Title level={4}>Select Payment Method:</Title>
        <Radio.Group onChange={handlePaymentMethodChange} value={paymentMethod}>
          <Radio.Button value="creditCard">Credit Card</Radio.Button>
          <Radio.Button value="upi">UPI</Radio.Button>
        </Radio.Group>
      </div>

      {showCreditCard && (
        <div style={{ marginTop: "20px" }}>
          <Title level={4}>Enter Credit Card Details</Title>
          <Input placeholder="Card Number" style={{ marginBottom: "10px" }} />
          <Input placeholder="Cardholder Name" style={{ marginBottom: "10px" }} />
          <Input placeholder="Expiration Date" style={{ marginBottom: "10px" }} />
          <Input placeholder="CVV" style={{ marginBottom: "10px" }} />
          <Button
            type="primary"
            block
            onClick={handlePaymentSuccess}
            style={{ marginTop: "10px" }}
          >
            Pay
          </Button>
        </div>
      )}

      {showUPI && (
        <div style={{ marginTop: "20px" }}>
          <Title level={4}>Scan to Pay via UPI</Title>
          <div
            style={{
              border: "1px dashed #d9d9d9",
              padding: "30px",
              textAlign: "center",
              marginBottom: "20px",
            }}
          >
            <Text>Scan the QR code to pay ₹{totalPrice}</Text>
            <div
              style={{
                backgroundColor: "#f5f5f5",
                height: "150px",
                marginTop: "20px",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
              }}
            >
              <Text>QR Code (Placeholder)</Text>
            </div>
          </div>
          <Button type="primary" block onClick={handlePaymentSuccess}>
            Done
          </Button>
        </div>
      )}
    </Card>
  );
}

export default PaymentPage;
