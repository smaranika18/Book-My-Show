import React, { useEffect, useState } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import axios from "axios";
import {
  Typography,
  DatePicker,
  Button,
  Modal,
  InputNumber,
  Card,
  Row,
  Col,
  message,
} from "antd";

const { Title } = Typography;

function ShowPage() {
  const { state } = useLocation();
  const { movieId, movieName } = state || {};
  const [theaters, setTheaters] = useState([]);
  const [selectedDate, setSelectedDate] = useState(null);
  const [selectedTheater, setSelectedTheater] = useState(null);
  const [showtimes, setShowtimes] = useState([]);
  const [selectedShow, setSelectedShow] = useState(null);
  const [numSeats, setNumSeats] = useState(1);
  const [showModal, setShowModal] = useState(false);

  const navigate = useNavigate();

  // Fetch theaters on mount
  useEffect(() => {
    const fetchTheaters = async () => {
      try {
        const response = await axios.get(
          "http://localhost:8080/api/theaters/getAllTheater"
        );
        setTheaters(response.data);
      } catch (error) {
        console.error("Error fetching theaters:", error);
        message.error("Failed to fetch theaters. Please try again later.");
      }
    };
    fetchTheaters();
  }, []);

  // Fetch shows when a theater is selected
  const handleTheaterSelect = async (theaterId) => {
    setSelectedTheater(theaterId);
    try {
      const response = await axios.get(
        `http://localhost:8080/api/shows/theater/${theaterId}`
      );
      setShowtimes(response.data);
    } catch (error) {
      console.error("Error fetching showtimes:", error);
      message.error("Failed to fetch showtimes. Please try again later.");
    }
  };

  // Handle showtime button click
  const handleShowtimeClick = (show) => {
    setSelectedShow(show);
    setShowModal(true);
  };

  // Proceed to seat selection page
  const handleProceedToSeatSelection = () => {
    setShowModal(false);
    navigate("/select-seats", {
      state: {
        movieId,
        movieName,
        theaterId: selectedTheater,
        showTime: selectedShow.showTime,
        ticketPrice: selectedShow.ticketPrice,
        numSeats,
      },
    });
  };

  // Ensure movie is selected
  if (!movieId || !movieName) {
    return <Title level={3}>Please select a movie to view showtimes.</Title>;
  }

  return (
    <div style={{ padding: "20px" }}>
      <Title level={2}>Book Tickets for {movieName}</Title>

      {/* Date Selector */}
      <div style={{ marginBottom: "20px" }}>
        <Title level={4}>Select Date:</Title>
        <DatePicker
          value={selectedDate}
          onChange={(date) => setSelectedDate(date)}
          style={{ width: "100%" }}
        />
      </div>

      {/* Theater List */}
      <Title level={4}>Theaters:</Title>
      <Row gutter={[16, 16]}>
        {theaters.map((theater) => (
          <Col key={theater.id} xs={24} sm={12} md={8} lg={6}>
            <Card
              hoverable
              onClick={() => handleTheaterSelect(theater.id)}
              style={{
                border: selectedTheater === theater.id ? "2px solid #1890ff" : "",
              }}
            >
              <Title level={5}>{theater.name}</Title>
            </Card>
          </Col>
        ))}
      </Row>

      {/* Showtimes */}
      <Title level={4}>Showtimes:</Title>
      <Row gutter={[16, 16]}>
        {showtimes.map((show) => (
          <Col key={show.id} xs={24} sm={12} md={8} lg={6}>
            <Button
              type="primary"
              block
              onClick={() => handleShowtimeClick(show)}
            >
              {show.showTime} - ₹{show.ticketPrice.toFixed(2)}
            </Button>
          </Col>
        ))}
      </Row>

      {/* Modal for selecting number of seats */}
      <Modal
        title="Select Number of Seats"
        visible={showModal}
        onOk={handleProceedToSeatSelection}
        onCancel={() => setShowModal(false)}
        okText="Select Seats"
        cancelText="Cancel"
      >
        <InputNumber
          min={1}
          value={numSeats}
          onChange={(value) => setNumSeats(value)}
          style={{ width: "100%" }}
        />
      </Modal>
    </div>
  );
}

export default ShowPage;
