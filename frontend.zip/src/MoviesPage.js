import React, { useEffect, useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import axios from "axios";
import { Card, Row, Col, Typography, Button, message } from "antd";

const { Title, Text } = Typography;

function MoviesPage() {
  const { state } = useLocation();
  const { location } = state || {}; // Extract location from state
  const [movies, setMovies] = useState([]);
  const navigate = useNavigate();

  useEffect(() => {
    if (location) {
      const fetchMovies = async () => {
        try {
          const response = await axios.get(
            `http://localhost:8080/api/movies/${location}`
          );
          setMovies(response.data);
        } catch (error) {
          console.error("Error fetching movies:", error);
          message.error("Failed to fetch movies. Please try again later.");
        }
      };
      fetchMovies();
    }
  }, [location]);

  if (!location) {
    return (
      <div style={{ textAlign: "center", marginTop: "50px" }}>
        <Title level={3}>Please log in and select a location to view movies.</Title>
      </div>
    );
  }

  return (
    <div style={{ padding: "20px" }}>
      <Title level={2}>Movies Available in {location}</Title>
      <Row gutter={[16, 16]}>
        {movies.map((movie) => (
          <Col key={movie.id} xs={24} sm={12} md={8} lg={6}>
            <Card
              hoverable
              cover={
                <img
                  src={movie.imageUrl} // Image coming from backend
                  alt={movie.name}
                  style={{ borderRadius: "8px", height: "250px", objectFit: "cover" }}
                />
              }
            >
              <Card.Meta
                title={<Title level={5}>{movie.name}</Title>}
                description={
                  <>
                    <Text>{movie.description}</Text>
                    <br />
                    <Text strong>Genre:</Text> {movie.genre}
                    <br />
                    <Text strong>Duration:</Text> {movie.duration} mins
                  </>
                }
              />
              <Button
                type="primary"
                block
                style={{ marginTop: "10px" }}
                onClick={() =>
                  navigate("/shows", {
                    state: { movieId: movie.id, movieName: movie.name },
                  })
                }
              >
                Book Tickets
              </Button>
            </Card>
          </Col>
        ))}
      </Row>
    </div>
  );
}

export default MoviesPage;
