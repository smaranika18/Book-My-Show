import React, { useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { Button, Modal, Typography, Row, Col, Card, notification } from "antd";

const { Title, Text } = Typography;

function SelectSeatsPage() {
  const { state } = useLocation();
  const { movieName, theaterName, showTime, ticketPrice } = state || {};
  const [selectedSeats, setSelectedSeats] = useState([]);
  const [isModalVisible, setIsModalVisible] = useState(false);
  const navigate = useNavigate();

  const handleSeatSelection = (seat) => {
    if (selectedSeats.includes(seat)) {
      setSelectedSeats(selectedSeats.filter((s) => s !== seat));
    } else {
      setSelectedSeats([...selectedSeats, seat]);
    }
  };

  const calculateTotalPrice = () => {
    const basePrice = ticketPrice * selectedSeats.length;
    const gst = basePrice * 0.05; // 5% GST
    return (basePrice + gst).toFixed(2);
  };

  const handlePay = () => {
    if (selectedSeats.length === 0) {
      notification.error({
        message: "No Seats Selected",
        description: "Please select at least one seat before proceeding.",
      });
      return;
    }
    setIsModalVisible(true);
  };

  const handleMakePayment = () => {
    navigate("/payment", {
      state: {
        movieName,
        theaterName,
        showTime,
        numSeats: selectedSeats.length,
        totalPrice: calculateTotalPrice(),
      },
    });
  };

  return (
    <div style={{ padding: "20px" }}>
      <Title level={2}>Select Seats for {movieName}</Title>
      <Row gutter={[16, 16]}>
        {Array.from({ length: 50 }, (_, index) => (
          <Col key={index} span={2}>
            <Card
              hoverable
              style={{
                textAlign: "center",
                backgroundColor: selectedSeats.includes(index + 1) ? "#52c41a" : "#f0f0f0",
              }}
              onClick={() => handleSeatSelection(index + 1)}
            >
              {index + 1}
            </Card>
          </Col>
        ))}
      </Row>

      <div style={{ marginTop: "20px" }}>
        <Text strong>Selected Seats:</Text> {selectedSeats.join(", ") || "None"}
        <br />
        <Button
          type="primary"
          onClick={handlePay}
          style={{ marginTop: "10px" }}
        >
          Pay
        </Button>
      </div>

      <Modal
        title="Payment Details"
        visible={isModalVisible}
        onOk={handleMakePayment}
        onCancel={() => setIsModalVisible(false)}
        okText="Make Payment"
        cancelText="Close"
      >
        <Text>
          <strong>Movie:</strong> {movieName}
        </Text>
        <br />
        <Text>
          <strong>Theater:</strong> {theaterName || "Not Available"}
        </Text>
        <br />
        <Text>
          <strong>Showtime:</strong> {showTime || "Not Available"}
        </Text>
        <br />
        <Text>
          <strong>Number of Seats:</strong> {selectedSeats.length}
        </Text>
        <br />
        <Text>
          <strong>Total Price (incl. 5% GST):</strong> ₹{calculateTotalPrice()}
        </Text>
      </Modal>
    </div>
  );
}

export default SelectSeatsPage;