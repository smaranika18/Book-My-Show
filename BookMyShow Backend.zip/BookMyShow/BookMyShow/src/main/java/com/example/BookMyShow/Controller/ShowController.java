package com.example.BookMyShow.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.BookMyShow.Entity.Show;
import com.example.BookMyShow.Service.ShowService;
@RestController
@CrossOrigin("*")
@RequestMapping("/api/shows")
public class ShowController {
     @Autowired
    private ShowService showService;

    @GetMapping("/movie/{movieId}")
    public List<Show> getShowsByMovie(@PathVariable Long movieId) {
        return showService.getShowsByMovie(movieId);
    }

    @GetMapping("/theater/{theaterId}")
    public List<Show> getShowsByTheater(@PathVariable Long theaterId) {
        return showService.getShowsByTheater(theaterId);
    }
      @PostMapping("/add")
    public ResponseEntity<Show> addShow(
            @RequestParam Long movieId,
            @RequestParam Long theaterId,
            @RequestParam String showTime,
            @RequestParam double ticketPrice) {
        Show newShow = showService.addShow(movieId, theaterId, showTime, ticketPrice);
        return ResponseEntity.ok(newShow);
    }
}
