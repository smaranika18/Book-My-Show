package com.example.BookMyShow.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.BookMyShow.Entity.Theater;
import com.example.BookMyShow.Repository.TheaterRepository;
@Service
public class TheaterService {
    @Autowired
    private TheaterRepository theaterRepository;

    public List<Theater> getTheatersByLocation(String location) {
        return theaterRepository.findByLocation(location);
    }
    public Theater addTheater(Theater theater){
        return theaterRepository.save(theater);
    }
    public String deleteTheater(Long id){
        if (theaterRepository.existsById(id))
        {
            theaterRepository.deleteById(id);
            return "Movie deleted successfully";
        }
        else
        {
            throw new RuntimeException("Movie not found with id: " + id);
        }
    }
    public Theater updateTheater(Long id, Theater updatedTheater) {
        return theaterRepository.findById(id).map(existingTheater -> {
            existingTheater.setName(updatedTheater.getName());
            existingTheater.setLanguage(updatedTheater.getLanguage());
            existingTheater.setLocation(updatedTheater.getLocation());
            return theaterRepository.save(existingTheater);
        }).orElseThrow(() -> new RuntimeException("Theater not found with id: " + id));
    }
    public List<Theater> getAllTheaters(){
        return theaterRepository.findAll();
    }
}
