package com.example.BookMyShow.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.BookMyShow.Entity.Booking;

public interface BookingRepository extends JpaRepository<Booking, Long> {

}
