package com.example.BookMyShow.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.BookMyShow.Entity.Booking;
import com.example.BookMyShow.Entity.Movie;
import com.example.BookMyShow.Entity.Show;
import com.example.BookMyShow.Service.BookingService;

@RestController
@CrossOrigin("*")
@RequestMapping("/api")
public class BookingController {
     @Autowired
    private BookingService bookingService;

    @GetMapping("/bookings/{location}")
    public List<Movie> getMovies(@PathVariable String location) {
        return bookingService.getMoviesByLocation(location);
    }

    @GetMapping("/shows/{movieId}")
    public List<Show> getShows(@PathVariable Long movieId) {
        return bookingService.getShowsByMovie(movieId);
    }

    @PostMapping("/book")
    public ResponseEntity<Booking> bookSeats(
            @RequestParam Long userId, 
            @RequestParam Long showId, 
            @RequestBody List<String> seats) {
        try {
            // Directly using request params and request body
            Booking booking = bookingService.bookSeats(userId, showId, seats);
            return ResponseEntity.ok(booking);
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(null);
        }
    }
    @PostMapping("/confirm-payment")
    public ResponseEntity<String> confirmPayment(
            @RequestParam Long bookingId, 
            @RequestParam String paymentMethod) {
        try {
            // Call service method to confirm payment and set payment status
            Booking booking = bookingService.confirmPayment(bookingId);

            // Simulate different payment methods (e.g., Credit Card, PayPal, etc.)
            String paymentStatusMessage = bookingService.handlePaymentMethod(paymentMethod);

            // Return success message with payment status
            return ResponseEntity.ok("Payment confirmed via " + paymentMethod + ". " + paymentStatusMessage);
        } catch (Exception e) {
            return ResponseEntity.badRequest().body("Error: " + e.getMessage());
        }
    }
}
