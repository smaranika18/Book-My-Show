package com.example.BookMyShow.Repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.BookMyShow.Entity.Movie;

public interface MovieRepository extends JpaRepository<Movie, Long> {
    List<Movie> findByLocation(String location);
}
