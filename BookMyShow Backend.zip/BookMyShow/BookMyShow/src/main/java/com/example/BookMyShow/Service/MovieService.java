package com.example.BookMyShow.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.BookMyShow.Entity.Movie;
import com.example.BookMyShow.Repository.MovieRepository;
@Service
public class MovieService {
    @Autowired
    private MovieRepository movieRepository;

    public List<Movie> getMoviesByLocation(String location) {
        return movieRepository.findByLocation(location);
    }
    public Movie addMovie(Movie movie){
        return movieRepository.save(movie);
    }
    public String deleteMovie(Long id){
        if (movieRepository.existsById(id)) {
            movieRepository.deleteById(id);
            return "Movie deleted successfully";
        } else {
            throw new RuntimeException("Movie not found with id: " + id);
        }
    }
    public List<Movie> getAllMovies(){
       return movieRepository.findAll();
    }
}
