package com.example.BookMyShow.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;
import com.example.BookMyShow.Entity.Booking;
import com.example.BookMyShow.Entity.Movie;
import com.example.BookMyShow.Entity.Show;
import com.example.BookMyShow.Entity.User;
import com.example.BookMyShow.Repository.BookingRepository;
import com.example.BookMyShow.Repository.MovieRepository;
import com.example.BookMyShow.Repository.ShowRepository;
import com.example.BookMyShow.Repository.UserRepository;

@Service
public class BookingService {
    @Autowired
    private MovieRepository movieRepository;
    @Autowired
    private ShowRepository showRepository;
    @Autowired
    private BookingRepository bookingRepository;
    @Autowired
    private UserRepository userRepository;

    public List<Movie> getMoviesByLocation(String location) {
        return movieRepository.findByLocation(location);
    }

    public List<Show> getShowsByMovie(Long movieId) {
        return showRepository.findByMovieId(movieId);
    }

    // public Booking bookSeats(Long userId, Long showId, List<String> seats) {
    //     Show show = showRepository.findById(showId).orElseThrow();
    //     double totalPrice = show.getTicketPrice() * seats.size();
    //     Booking booking = new Booking();
    //     booking.setId(userId);
    //     booking.setShow(show);
    //     booking.setNumberOfSeats(seats.size());
    //     booking.setSeatNumbers(String.join(",", seats));
    //     booking.setTotalPrice(totalPrice);
    //     booking.setPaymentStatus(false); // Payment pending
    //     return bookingRepository.save(booking);
    // }
    public Booking bookSeats(Long userId, Long showId, List<String> seats) {
        Show show = showRepository.findById(showId)
                .orElseThrow(() -> new RuntimeException("Show not found"));
    
        // Validate seat availability (simplified for now)
        if (seats.size() > 10) { // Example constraint: max 10 seats per booking
            throw new RuntimeException("Cannot book more than 10 seats");
        }
    
        double totalPrice = show.getTicketPrice() * seats.size();
    
        Booking booking = new Booking();
        User user = userRepository.findById(userId) // Assuming you have a user repository
                .orElseThrow(() -> new RuntimeException("User not found"));
    
        booking.setUser(user); // Set the user object (not just the userId)
        booking.setShow(show);
        booking.setNumberOfSeats(seats.size());
        booking.setSeatNumbers(String.join(",", seats));
        booking.setTotalPrice(totalPrice);
        booking.setPaymentStatus(false); // Payment pending
    
        return bookingRepository.save(booking);
    }
    
    public Booking confirmPayment(Long bookingId) {
        // Retrieve the booking from the database
        Booking booking = bookingRepository.findById(bookingId)
                .orElseThrow(() -> new RuntimeException("Booking not found"));

        // Set payment status to true (Payment confirmed)
        booking.setPaymentStatus(true);
        return bookingRepository.save(booking);
    }

    // Simulate different payment methods (e.g., Credit Card, PayPal, etc.)
    public String handlePaymentMethod(String paymentMethod) {
        // Example: Simulating payment processing based on method
        switch (paymentMethod.toLowerCase()) {
            case "creditcard":
                return "Payment processed successfully with Credit Card.";
            case "paypal":
                return "Payment processed successfully via PayPal.";
            case "netbanking":
                return "Payment processed successfully via Net Banking.";
            default:
                throw new RuntimeException("Invalid payment method");
        }
    }
}
